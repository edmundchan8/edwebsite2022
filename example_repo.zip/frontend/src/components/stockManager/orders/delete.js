import React from 'react';

function DeleteStocks(props) {
    return(
        <div>Delete Stocks component is here</div>
    )
}

export default DeleteStocks;