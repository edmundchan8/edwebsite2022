import React from 'react';

function DeleteDividends(props) {
    return(
        <div>This is the Delete Dividends component</div>
    )
}

export default DeleteDividends;