git add .
git commit -m "updates"
git push
git push production master
